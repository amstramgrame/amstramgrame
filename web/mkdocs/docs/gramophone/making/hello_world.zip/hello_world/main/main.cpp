#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_spi_flash.h"

#include "WM8978.h"
#include "FaustSawtooth.h"

#include <driver/adc.h>
//#include <MPU9250_asukiaaa.h>

extern "C" {
    void app_main(void);
}

void app_main(void)
{
  WM8978 wm8978;
  wm8978.init();
  wm8978.addaCfg(1,1); 
  wm8978.inputCfg(1,0,0);     
  wm8978.outputCfg(1,0); 
  wm8978.micGain(30);
  wm8978.auxGain(0);
  wm8978.lineinGain(0);
  wm8978.spkVolSet(0);
  wm8978.hpVolSet(40,40);
  wm8978.i2sCfg(2,0);
  
  adc1_config_width(ADC_WIDTH_BIT_12);
    
  int SR = 48000;
  int BS = 8;
  FaustSawtooth faustSawtooth(SR,BS);  
  faustSawtooth.start();
  
  // ADC1_CHANNEL_7 : GPIO35 : works
  // ADC1_CHANNEL_6 : GPIO34 : works
  // ADC1_CHANNEL_4 : GPIO32 : works
  // ADC2_CHANNEL_1 : GPIO00 : for some reasons doesn't work
  // ADC2_CHANNEL_2 : GPIO02 : works
  // ADC2_CHANNEL_3 : GPIO15 : works
  // ADC2_CHANNEL_0 : GPIO04 : works
  // ADC2_CHANNEL_5 : GPIO12 : works
  // ADC2_CHANNEL_4 : GPIO13 : works
  // ADC2_CHANNEL_6 : GPIO14 : works
  
  gpio_config_t io_conf;
  io_conf.intr_type = (gpio_int_type_t) GPIO_PIN_INTR_POSEDGE;
  io_conf.pin_bit_mask = ((1ULL<<4) | (1ULL<<13) | (1ULL<<14) | (1ULL<<15));
  io_conf.mode = GPIO_MODE_INPUT;
  io_conf.pull_up_en = (gpio_pullup_t) 1;
  gpio_config(&io_conf);
  
  int spkGain_old = -1;
  
  while(1) {
    int gain = adc1_get_raw(ADC1_CHANNEL_7);
    int encoder_dt = gpio_get_level(GPIO_NUM_4);
    int encoder_clk = gpio_get_level(GPIO_NUM_13);
    int photores = adc1_get_raw(ADC1_CHANNEL_6);
    int knob = adc1_get_raw(ADC1_CHANNEL_4);
    //adc2_get_raw( ADC2_CHANNEL_0, ADC_WIDTH_12Bit, &knob);
    int button = gpio_get_level(GPIO_NUM_14);
    int encoder_button = gpio_get_level(GPIO_NUM_15);
    
    int spkGain = gain*0.01538461538;
    if(spkGain != spkGain_old){
      wm8978.spkVolSet(spkGain);
      spkGain_old = spkGain;
    }
    
    int encoder_status;
    if(encoder_button == 0){
      encoder_status = encoder_dt;
    }
    else{
      encoder_status = encoder_clk;
    }
    int synth_gain = button*encoder_status;
    
    int synth_freq; 
    if(knob == 4095){
      synth_freq = photores*0.25 + 50;
    }
    else{
      synth_freq = knob + 50;
    }
    
    faustSawtooth.setParamValue("freq",synth_freq);
    faustSawtooth.setParamValue("gain",synth_gain);
    vTaskDelay(10 / portTICK_PERIOD_MS);
  }
}
